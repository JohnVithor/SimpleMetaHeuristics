python src/RunVNS.py 17 42 4 1500 750 120 10 vns.csv

python src/RunGRASP.py 17 42 0.0 3 7500 2500 10 120 10 grasp.csv

python src/RunGenetic.py 17 42 10 0.8 0.1 1000 3000 120 10 genetic.csv

python src/RunGetBest.py 17 grasp.csv genetic.csv vns.csv best.csv